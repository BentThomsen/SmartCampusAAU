﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WifiSnifferPositioningService.radiomap;

namespace WifiSnifferPositioningService.extensions.wifi
{
    public static class SnifferWifiMeasurementExtensions
    {
        //We are not too concerned with decimal numbers, so we return the avg as an int
        //(Moreover, this is a legacy from the WinMobile client and the Streamspin server)
        public static double getAvgDbM(this SnifferWifiMeasurement source, string mac)
        {
            int totalVal = 0;
            int totalCount = 0; //the total number of distinct values
            //calculate the total
            foreach (SnifferHistogram sniff in source.SnifferHistograms)
            {
                if (sniff.Mac == mac)
                {
                    totalVal += sniff.value * sniff.count;
                    totalCount += sniff.count;
                }
            }              

            return totalVal / totalCount;        
        }     

        public static List<string> getMACs(this SnifferWifiMeasurement source)
        {
            List<String> result = new List<string>();
            foreach (SnifferHistogram h in source.SnifferHistograms)
            {
                if (!result.Contains(h.Mac))
                    result.Add(h.Mac);
            }
            return result;
        }
        
        public static bool containsMac(this SnifferWifiMeasurement source, string mac)
        {
            foreach (SnifferHistogram h in source.SnifferHistograms)
            {
                if (h.Mac.Equals(mac))
                    return true;
            }
            return false;
        }
    }
}

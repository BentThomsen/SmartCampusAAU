﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WifiSnifferPositioningService.radiomap;

namespace WifiSnifferPositioningService.extensions.indoormodel.graph
{
    public static class VertexExtension
    {
        public static IEnumerable<Vertex> adjacentVertices(this Vertex source)
        {
            List<Vertex> result = new List<Vertex>();
            
            foreach (Edge e in source.Edges)
            {
                foreach (Vertex v in e.Vertices)
                {
                    if (!(v.ID == source.ID))
                        result.Add(v);
                }
            }

            return result;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Services.Common;

namespace WifiSnifferPositioningService
{
    public class SnifferModel
    {
        private List<PositionEstimate> _positionEstimates = new List<PositionEstimate>();

        public SnifferModel()
        {
            PositionEstimate dummyPos = new PositionEstimate();
            dummyPos.ID = 0;
            dummyPos.VertexID = 1;
            dummyPos.Latitude = 10;
            dummyPos.Longitude = 20;
            dummyPos.Altitude = 3;
            dummyPos.Time = DateTime.Now;

            _positionEstimates.Add(dummyPos);           
        }        

        public IQueryable<PositionEstimate> PositionEstimates 
        {
            get { return _positionEstimates.AsQueryable<PositionEstimate>(); }
        }
    }

    [DataServiceKey("ID")]
    public class PositionEstimate
    {
        public int ID { get; set; }
        public int Building_ID { get; set; }

        //estimated position's vertex id
        public int VertexID { get; set; }

        /// AbsoluteLocation
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public double Altitude { get; set; }

        public string Provider { get; set; } //wifi, gps eller andet
        public DateTime Time { get; set; }
        public double Accuracy { get; set; }
        public double Speed { get; set; }
        public double Bearing { get; set; }

        public Boolean HasAccuracy { get; set; }
        public bool HasSpeed { get; set; }
        public bool HasBearing { get; set; }        
    }    
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WifiSnifferPositioningService.radiomap;

namespace WifiSnifferPositioningService.location.wifi
{
    public interface IPositioningAlgorithm
    {
        EstimateResult compare(IEnumerable<Vertex> vertices, SnifferWifiMeasurement measurement);
    }
}
